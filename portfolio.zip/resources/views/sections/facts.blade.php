<div class="container">

<div class="section-title">
  <h2>Facts</h2>
  <p>The first thing for me is that customers are happy and satisfied.</p>
</div>

<div class="row no-gutters">

  <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up">
    <div class="count-box">
      <i class="bi bi-emoji-smile"></i>
      <span data-purecounter-start="0" data-purecounter-end="5" data-purecounter-duration="1" class="purecounter"></span>
      <p><strong>Happy Clients</strong> consequuntur quae</p>
    </div>
  </div>

  <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="100">
    <div class="count-box">
      <i class="bi bi-journal-richtext"></i>
      <span data-purecounter-start="0" data-purecounter-end="3" data-purecounter-duration="1" class="purecounter"></span>
      <p><strong>Projects</strong> adipisci atque cum quia aut</p>
    </div>
  </div>

  <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="200">
    <div class="count-box">
      <i class="bi bi-headset"></i>
      <span data-purecounter-start="0" data-purecounter-end="65" data-purecounter-duration="1" class="purecounter"></span>
      <p><strong>Hours Of Support</strong> aut commodi quaerat</p>
    </div>
  </div>

  <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="300">
    <div class="count-box">
      <i class="bi bi-people"></i>
      <span data-purecounter-start="0" data-purecounter-end="3" data-purecounter-duration="1" class="purecounter"></span>
      <p><strong>Hard Workers</strong> rerum asperiores dolor</p>
    </div>
  </div>

</div>

</div>