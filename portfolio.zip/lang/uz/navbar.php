<?
return [
    'home' => 'Bosh sahifa',
    'about' => 'Ma`lumot',
    'portfolio' => 'Portfel',
    'services' => 'Xizmatlar',
    'contact' => 'Aloqa',
]


?>