<?
return [
    'name' => 'Rashidjon Yunusov',
    'my' => 'Men',
    'jobs' => 'Web dasturchi, Video montaj, SMM, Mobilagraf',
]


?>