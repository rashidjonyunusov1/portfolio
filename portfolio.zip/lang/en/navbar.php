<?
return [
    'home' => 'Home',
    'about' => 'About',
    'portfolio' => 'Portfolio',
    'services' => 'Services',
    'contact' => 'Contact',
]


?>