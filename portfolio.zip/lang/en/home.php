<?
return [
    'name' => 'Rashidjon Yunusov',
    'my' => "I'm",
    'jobs' => 'Web developer, Video Editor, SMM, Mobilagraph',
]


?>