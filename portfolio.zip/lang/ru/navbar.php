<?
return [
    'home' => 'Дом',
    'about' => 'Обо мне',
    'portfolio' => 'портфолио',
    'services' => 'Услуги',
    'contact' => 'Контакт',
]


?>