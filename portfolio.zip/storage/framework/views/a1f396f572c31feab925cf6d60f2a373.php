


<?php $__env->startSection('content'); ?>

    <!-- MAIN -->
        <main>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Edit Contacts</h3>
                        <a class="create__btn" href="<?php echo e(route('admin.contacts.index')); ?>"> <i class="bi bi-backspace-fill"></i>Qaytish</a>

                    </div>

                    <form class="create__inputs" action="<?php echo e(route('admin.contacts.update', $contact->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <strong> Description Uz:</strong>
                        <input type="text" name="description_uz" value="<?php echo e($contact->description_uz); ?>" class="form-control"> <br>

                        <strong> Description Ru:</strong>
                        <input type="text" name="description_ru" value="<?php echo e($contact->description_ru); ?>" class="form-control"> <br>

                        <strong> Description En:</strong>
                        <input type="text" name="description_en" value="<?php echo e($contact->description_en); ?>" class="form-control"> <br>


                        <strong> Location Uz:</strong>
                        <input type="text" name="location_uz" value="<?php echo e($contact->location_uz); ?>" class="form-control"> <br>

                        <strong> Location :</strong>
                        <input type="text" name="location_ru" value="<?php echo e($contact->location_ru); ?>" class="form-control"> <br>

                        <strong> Location :</strong>
                        <input type="text" name="location_en" value="<?php echo e($contact->location_en); ?>" class="form-control"> <br>


                        <strong> Email :</strong>
                        <input type="email" name="email" value="<?php echo e($contact->email); ?>" class="form-control"> <br>

                        <strong> Call :</strong>
                        <input type="text" name="call" value="<?php echo e($contact->call); ?>" class="form-control"> <br>

                        <strong> Location URL :</strong>
                        <input type="text" name="location_url" value="<?php echo e($contact->location_url); ?>" class="form-control"> <br>

                        <input type="submit" value="Edit">

                    </form>
                </div>

            </div>
        </main>
        <!-- MAIN -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/contacts/edit.blade.php ENDPATH**/ ?>