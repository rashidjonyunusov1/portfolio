<div class="hero-container" data-aos="fade-in">
  
      <h1>Rashidjon Yunusov</h1>
      <p><b>I'm</b> <b><span class="typed" data-typed-items="Developer, Businessman, Photographer, SMM"></span></b></p>
      <br><br>
      <!-- <h3> <a  style="color: black;" href="/curswork/index.html" target="_blank">My Projects</a></h3> -->
    </div><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/sections/home.blade.php ENDPATH**/ ?>