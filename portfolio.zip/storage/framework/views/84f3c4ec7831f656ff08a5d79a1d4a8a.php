
<?php $__env->startSection('contacts'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('warning')): ?>
            <div class="alert alert-warning">
                <p style="color: black;"><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
	<!-- MAIN -->
    <main>

        <div class="table-data">
            <div class="order">
                <div class="head">
                    <h3>Contacts</h3>
                  <a class="create__btn" href="<?php echo e(route('admin.contacts.create')); ?>"><i class="bi bi-plus-circle-fill">
                    </i>Yaratish</a>
                </div>
                <table class="table table-bordered table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th scope="col">Description Uz</th>
                            
                            <th scope="col">Call</th>
                            
                            <th scope="col">Data</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        
                        <tr>
                            <td><?php echo e(++$loop->index); ?></td>
                            <td><?php echo \Str::limit($item->description_uz,20); ?></td>
                            
                            <td><?php echo e($item->call); ?></td>
                            
                            <td><?php echo e($item->created_at); ?></td>
                            <td>

                                <form method="POST" action="<?php echo e(route('admin.contacts.destroy', $item->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <a class="btn btn-primary" href="<?php echo e(route('admin.contacts.show', $item->id)); ?>"><i class="bi bi-eye-fill"></i></a>
                                    <a class="btn btn-primary" href="<?php echo e(route('admin.contacts.edit', $item->id)); ?>"><i class="bi bi-pencil-fill"></i></a>

                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Do you want to delete ?')"><i class="bi bi-trash-fill"></i></button>

                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                 <?php echo e($contact ->links()); ?>

            </div>
           
        </div>
    </main>
    <!-- MAIN -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>