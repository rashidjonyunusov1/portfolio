


<?php $__env->startSection('content'); ?>

<!-- MAIN -->
<main>


    <div class="table-data">
        <div class="order">
            <div class="head">
                <h3>Show</h3>
                <a class="create__btn" href="<?php echo e(route('admin.skills.index')); ?>"> <i class="bi bi-backspace-fill"></i>Back</a>
            </div>
            <table>
                <tr>
                    <td>ID</td>
                    <td><?php echo e($skill->id); ?></td>
                </tr>
                <tr>
                    <td>Description UZ</td>
                    <td><?php echo $skill->description_uz; ?></td>
                </tr>
                <tr>
                    <td>Description Ru</td>
                    <td><?php echo $skill->description_ru; ?></td>
                </tr>
                <tr>
                    <td>Description En</td>
                    <td><?php echo $skill->description_en; ?></td>
                </tr>
                <tr>
                    <td>Skills Name Right</td>
                    <td><?php echo e($skill->skill_name_r); ?></td>
                </tr>
                <tr>
                    <td>Skills Percentage Right</td>
                    <td>
                       <td><?php echo e($skill->skill_percentage_r); ?></td>
                    </td>
                </tr>
                <tr>
                    <td>Skills Name Left</td>
                    <td><?php echo e($skill->skill_name_l); ?></td>
                </tr>
                <tr>
                    <td>Skills Percentage Left</td>
                    <td>
                       <td><?php echo e($skill->skill_percentage_l); ?></td>
                    </td>
                </tr>
            </table>
        </div>

    </div>
</main>
<!-- MAIN -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/skills/show.blade.php ENDPATH**/ ?>