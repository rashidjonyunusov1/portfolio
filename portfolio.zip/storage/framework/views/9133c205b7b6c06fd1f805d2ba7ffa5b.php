

<div class="row">
  
  <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
  <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="200">
    <div class="icon"><i class="bi bi-bar-chart"></i></div>
    <h4 class="title"><a href=""><?php echo e($item['services_name_'.\App::getLocale()]); ?></a></h4>
    <p class="description"><?php echo e($item['services_description_'.\App::getLocale()]); ?></p>
  </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
</div>
<?php /**PATH C:\OSPanel\domains\portfolio\resources\views/sections/services.blade.php ENDPATH**/ ?>