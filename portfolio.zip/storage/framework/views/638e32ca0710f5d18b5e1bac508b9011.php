<div class="container">

<div class="section-title">
  <h2>Portfolio</h2>
  <p><?php echo $portfolios['description_'.\App::getLocale()]; ?></p>
</div>

<!-- <div class="row" data-aos="fade-up">
  <div class="col-lg-12 d-flex justify-content-center">
    <ul id="portfolio-flters">
      <li data-filter="*" class="filter-active">All</li>
      <li data-filter=".filter-app">App</li>
      <li data-filter=".filter-card">Card</li>
      <li data-filter=".filter-web">Web</li>
    </ul>
  </div>
</div> -->

<div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">


<?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <div class="col-lg-4 col-md-6 portfolio-item filter-app">
    <div class="portfolio-wrap">
      <img src="/img/<?php echo e($item->img); ?>" class="img-fluid" alt="">
      <div class="portfolio-links">
        <a href="<?php echo e($item->url); ?>" target="_blank"><i class="bx bx-link"></i></a>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 


</div>

</div><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/sections/portfolio.blade.php ENDPATH**/ ?>