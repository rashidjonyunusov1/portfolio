


<?php $__env->startSection('content'); ?>

    <!-- MAIN -->
        <main>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Edit Form</h3>
                        <a class="create__btn" href="<?php echo e(route('admin.forms.index')); ?>"> <i class="bi bi-backspace-fill"></i>Qaytish</a>

                    </div>

                    <form class="create__inputs" action="<?php echo e(route('admin.forms.update', $form->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <strong> Name :</strong>
                        <input type="text" name="name" value="<?php echo e($form->name); ?>" class="form-control"> <br>

                        <strong> Email :</strong>
                        <input type="email" name="email" value="<?php echo e($form->email); ?>" class="form-control"> <br>

                        <strong> Number :</strong>
                        <input type="text" name="number" value="<?php echo e($form->number); ?>" class="form-control"> <br>

                        <strong> Subject :</strong>
                        <input type="text" name="subject" value="<?php echo e($form->subject); ?>" class="form-control"> <br>

                        <strong> Message :</strong>
                        <input type="text" name="message" value="<?php echo e($form->message); ?>" class="form-control"> <br>

                        
                        <input type="submit" value="Edit">

                    </form>
                </div>

            </div>
        </main>
        <!-- MAIN -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/forms/edit.blade.php ENDPATH**/ ?>