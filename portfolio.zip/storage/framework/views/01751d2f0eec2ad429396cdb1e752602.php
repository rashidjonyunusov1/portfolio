


<?php $__env->startSection('content'); ?>

<!-- MAIN -->
<main>


    <div class="table-data">
        <div class="order">
            <div class="head">
                <h3>Show</h3>
                <a class="create__btn" href="<?php echo e(route('admin.portfolios.index')); ?>"><i class="bi bi-backspace-fill"></i>Back</a>
            </div>
            <table>
                <tr>
                    <td>ID</td>
                    <td><?php echo e($portfolio->id); ?></td>
                </tr>
                <tr>
                    <td>Description Uz</td>
                    <td><?php echo $portfolio->description_uz; ?></td>
                </tr>
                <tr>
                    <td>Description Ru</td>
                    <td><?php echo $portfolio->description_ru; ?></td>
                </tr>
                <tr>
                    <td>Description En</td>
                    <td><?php echo $portfolio->description_en; ?></td>
                </tr>
                
                <tr>
                    <td>URL En</td>
                    <td><?php echo e($portfolio->url); ?></td>
                </tr>
                <tr>
                    <td>Image</td>
                    <td>
                        <img src="/img/<?php echo e($portfolio->img); ?>" width="80px">
                    </td>
                </tr>
            </table>
        </div>

    </div>
</main>
<!-- MAIN -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/portfolios/show.blade.php ENDPATH**/ ?>