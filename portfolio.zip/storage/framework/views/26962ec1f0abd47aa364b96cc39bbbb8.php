
<div class="container">
<div class="section-title">  
  <h2>About</h2>
  <p>
    <?php echo $about['description1_'.\App::getLocale()]; ?>

    
  </p>
</div>



<div class="row">
  <div class="col-lg-4" data-aos="fade-right">
    <img src="/img/<?php echo e($about->img); ?>" class="img-fluid" alt="" style="margin-top: 30px;">
  </div>
  <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
    <h3>Businessman &amp; Web Developer.</h3>
    <p class="fst-italic">
    </p>
    <div class="row">
      <div class="col-lg-6">
        <ul>
          <li><i class="bi bi-chevron-right"></i> <strong>Birthday:</strong> <span><?php echo e($about['brithday_'.\App::getLocale()]); ?> </span></li>
          <li><i class="bi bi-chevron-right"></i> <strong>Website:</strong> <span><a><?php echo e($about->website); ?></a></span></li>
          <li><i class="bi bi-chevron-right"></i> <strong>Phone:</strong> <span><?php echo e($about->phone); ?></span></li>
          <li><i class="bi bi-chevron-right"></i> <strong>City:</strong> <span><?php echo e($about['city_'.\App::getLocale()]); ?></span></li>
          <li><i class="bi bi-chevron-right"></i> <strong>Resume:</strong> <span><a href="/resume/<?php echo e($resume->resume); ?>"style="border:1px solid antiquewhite;" class="btn btn--light" target="_blank" > <i class="bi bi-download" ></i>
            Resume
          </a></span></li>
        </ul>
      </div>
      <div class="col-lg-6">
        <ul>
          <li><i class="bi bi-chevron-right"></i> <strong>Age:</strong> <span><?php echo e($about->age); ?></span></li>
          <li><i class="bi bi-chevron-right"></i> <strong>Degree:</strong> <span><?php echo e($about['dagree_'.\App::getLocale()]); ?></span></li>
          <li><i class="bi bi-chevron-right"></i> <strong>Email:</strong> <span><?php echo e($about->email); ?></span></li>
          <li><i class="bi bi-chevron-right"></i> <strong>Freelance:</strong> <span><?php echo e($about['freelance_'.\App::getLocale()]); ?></span></li>
        </ul>
      </div>
    </div>
    <p>
      <?php echo $about['description2_'.\App::getLocale()]; ?>

      
    </p>
  </div>
</div>

</div>

<?php /**PATH C:\OSPanel\domains\portfolio\resources\views/sections/about.blade.php ENDPATH**/ ?>