<div class="container">

<div class="section-title">
  <h2>Skills</h2>
  <p><?php echo $skills['description_'.\App::getLocale() ]; ?></p>
  
</div>

<div class="row skills-content">

  <div class="col-lg-6" data-aos="fade-up">

    
<?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="progress">
      <span class="skill"><?php echo e($item->skill_name_r); ?> <i class="val"><?php echo e($item->skill_percentage_r); ?>%</i></span>
      <div class="progress-bar-wrap">
        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e($item->skill_percentage_r); ?>" aria-valuemin="0" aria-valuemax="100"></div>
      </div>
    </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
<?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="progress">
      <span class="skill"> <?php echo e($item->skill_name_l); ?> <i class="val"><?php echo e($item->skill_percentage_l); ?>%</i></span>
      <div class="progress-bar-wrap">
        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e($item->skill_percentage_l); ?>" aria-valuemin="0" aria-valuemax="100"></div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    

  </div>

</div>

</div><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/sections/skills.blade.php ENDPATH**/ ?>