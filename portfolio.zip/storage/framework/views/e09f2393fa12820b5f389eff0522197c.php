<div class="section-title">
          <h2>Contact</h2>
          <p>
            <?php echo $contact['description_'.\App::getLocale()]; ?>

            </p>
        </div>

        <div class="row" data-aos="fade-in">

              
          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p>
            <?php echo $contact['location_'.\App::getLocale()]; ?>

                  </p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p><?php echo e($contact->email); ?></p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p><?php echo e($contact->call); ?></p>
              </div>

              <div class="phone">
                <i class="bi bi-chat-dots"></i>
                <h4>Send message:</h4>
                &nbsp&nbsp&nbsp&nbsp&nbsp;<a href="https://t.me/suniy_intelektt"><button type="button" class="btn btn-primary btn-lg">Send</button></a>
              </div>
              
            </div>
           

          </div>

          <?php /**PATH C:\OSPanel\domains\portfolio\resources\views/sections/contacts.blade.php ENDPATH**/ ?>