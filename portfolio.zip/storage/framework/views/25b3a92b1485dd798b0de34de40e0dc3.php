


<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong>There were some problems with your input. <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

    <!-- MAIN -->
        <main>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Add Resume</h3>
                        <a class="create__btn" href="<?php echo e(route('admin.resume.index')); ?>"> <i class="bi bi-backspace-fill"></i></i>Qaytish</a>

                    </div>

                    <form class="create__inputs" action="<?php echo e(route('admin.resume.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <strong> Resume  Uz:</strong>
                        <input type="file" name="resume" value="<?php echo e(old('resume_uz')); ?>" class="form-control"> <br>


                        <input type="submit" value="Qo`shish">

                    </form>
                </div>

            </div>
        </main>
        <!-- MAIN -->

        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/resume/create.blade.php ENDPATH**/ ?>