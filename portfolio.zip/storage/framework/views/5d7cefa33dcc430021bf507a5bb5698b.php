


<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong>There were some problems with your input. <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

    <!-- MAIN -->
        <main>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Edit about</h3>
                        <a class="create__btn" href="<?php echo e(route('admin.abouts.index')); ?>"> <i class="bi bi-backspace-fill"></i>Qaytish</a>

                    </div>

                    <form class="create__inputs" action="<?php echo e(route('admin.abouts.update', $about->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <strong> title Uz:</strong>
                        <input type="text" name="title_uz" value="<?php echo e($about->title_uz); ?>" class="form-control"> <br>

                        <strong> title Ru:</strong>
                        <input type="text" name="title_ru" value="<?php echo e($about->title_ru); ?>" class="form-control"> <br>

                        <strong> title En:</strong>
                        <input type="text" name="title_en" value="<?php echo e($about->title_en); ?>" class="form-control"> <br>

                        <strong> Description1 Uz:</strong>
                        <input type="text" name="description1_uz" value="<?php echo $about->description1_uz; ?>" class="form-control"> <br>
                        
                        <strong> Description1 Ru:</strong>
                        <input type="text" name="description1_ru" value="<?php echo $about->description1_ru; ?>" class="form-control"> <br>

                        <strong> Description1 En:</strong>
                        <input type="text" name="description1_en" value="<?php echo $about->description1_en; ?>" class="form-control"> <br>

                        <strong> Description2 Uz:</strong>
                        <input type="text" name="description2_uz" value="<?php echo $about->description2_uz; ?>" class="form-control"> <br>

                        <strong> Description2 Ru:</strong>
                        <input type="text" name="description2_ru" value="<?php echo $about->description2_ru; ?>" class="form-control"> <br>

                        <strong> Description2 En:</strong>
                        <input type="text" name="description2_en" value="<?php echo $about->description2_en; ?>" class="form-control"> <br>

                        <strong> Brithday Uz:</strong>
                        <input type="text" name="brithday_uz" value="<?php echo e($about->brithday_uz); ?>" class="form-control"> <br>

                        <strong> Brithday Ru:</strong>
                        <input type="text" name="brithday_ru" value="<?php echo e($about->brithday_ru); ?>" class="form-control"> <br>

                        <strong> Brithday En:</strong>
                        <input type="text" name="brithday_en" value="<?php echo e($about->brithday_en); ?>" class="form-control"> <br>

                        <strong> Website :</strong>
                        <input type="text" name="website" value="<?php echo e($about->website); ?>" class="form-control"> <br>

                        <strong> Phone :</strong>
                        <input type="text" name="phone" value="<?php echo e($about->phone); ?>" class="form-control"> <br>

                        <strong> City Uz:</strong>
                        <input type="text" name="city_uz" value="<?php echo e($about->city_uz); ?>" class="form-control"> <br>

                        <strong> City Ru:</strong>
                        <input type="text" name="city_ru" value="<?php echo e($about->city_ru); ?>" class="form-control"> <br>

                        <strong> City En:</strong>
                        <input type="text" name="city_en" value="<?php echo e($about->city_en); ?>" class="form-control"> <br>

                        <strong> Age :</strong>
                        <input type="text" name="age" value="<?php echo e($about->age); ?>" class="form-control"> <br>

                        <strong> Dagree Uz:</strong>
                        <input type="text" name="dagree_uz" value="<?php echo e($about->dagree_uz); ?>" class="form-control"> <br>

                        <strong> Dagree Ru:</strong>
                        <input type="text" name="dagree_ru" value="<?php echo e($about->dagree_ru); ?>" class="form-control"> <br>

                        <strong> Dagree En:</strong>
                        <input type="text" name="dagree_en" value="<?php echo e($about->dagree_en); ?>" class="form-control"> <br>

                        <strong> Email :</strong>
                        <input type="email" name="email" value="<?php echo e($about->email); ?>" class="form-control"> <br>

                        <strong> Freelance Uz:</strong>
                        <input type="text" name="freelance_uz" value="<?php echo e($about->freelance_uz); ?>" class="form-control"> <br>

                        <strong> Freelance Ru:</strong>
                        <input type="text" name="freelance_ru" value="<?php echo e($about->freelance_ru); ?>" class="form-control"> <br>

                        <strong> Freelance En:</strong>
                        <input type="text" name="freelance_en" value="<?php echo e($about->freelance_en); ?>" class="form-control"> <br>

                        <img src="/img/<?php echo e($about->img); ?>" width="70px"><br><br>

                        <strong> Rasm(png yoki jpg) :</strong>
                        <input type="file" name="img" class="form-control"> <br>

                        <input type="submit" value="Edit">

                    </form>
                </div>

            </div>
        </main>
        <!-- MAIN -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/abouts/edit.blade.php ENDPATH**/ ?>