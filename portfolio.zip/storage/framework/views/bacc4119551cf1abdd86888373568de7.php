


<?php $__env->startSection('content'); ?>

<!-- MAIN -->
<main>


    <div class="table-data">
        <div class="order">
            <div class="head">
                <h3>Show</h3>
                <a class="create__btn" href="<?php echo e(route('admin.profile.index')); ?>"></i>Back</a>
            </div>
            <table>
                <tr>
                    <td>ID</td>
                    <td><?php echo e($profile->id); ?></td>
                </tr>
                <tr>
                    <td>Icon</td>
                    <td>
                        <img src="/img/<?php echo e($profile->img); ?>" width="80px">
                    </td>
                </tr>
            </table>
        </div>

    </div>
</main>
<!-- MAIN -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/profile/show.blade.php ENDPATH**/ ?>