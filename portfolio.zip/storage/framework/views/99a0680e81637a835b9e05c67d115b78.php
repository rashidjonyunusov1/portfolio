


<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong>There were some problems with your input. <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

    <!-- MAIN -->
        <main>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Add about</h3>
                        <a class="create__btn" href="<?php echo e(route('admin.abouts.index')); ?>"> <i class="bi bi-backspace-fill"></i></i>Qaytish</a>

                    </div>

                    <form class="create__inputs" action="<?php echo e(route('admin.abouts.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <strong> Title  Uz:</strong>
                        <input type="text" name="title_uz" value="<?php echo e(old('title_uz')); ?>" class="form-control"> <br>

                        <strong> Title Ru:</strong>
                        <input type="text" name="title_ru" value="<?php echo e(old('title_ru')); ?>" class="form-control"> <br>

                        <strong> Title En:</strong>
                        <input type="text" name="title_en" value="<?php echo e(old('title_en')); ?>" class="form-control"> <br>

                        <strong> Description1 Uz :</strong>
                        <textarea type="text" value="<?php echo e(old('description1_uz')); ?>" name="description1_uz" class="form-control ckeditor"> 
                        </textarea><br>
                        <?php $__errorArgs = ['description1_uz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?><br><br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <strong> Description1 Ru :</strong>
                        <textarea type="text" value="<?php echo e(old('description1_ru')); ?>" name="description1_ru" class="form-control ckeditor"> 
                        </textarea><br>
                        <?php $__errorArgs = ['description1_ru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?><br><br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <strong> Description1 En :</strong>
                        <textarea type="text" value="<?php echo e(old('description1_en')); ?>" name="description1_en" class="form-control ckeditor"> 
                        </textarea><br>
                        <?php $__errorArgs = ['description1_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?><br><br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <strong> Description2 Uz :</strong>
                        <textarea type="text" value="<?php echo e(old('description2_uz')); ?>" name="description2_uz" class="form-control ckeditor"> 
                        </textarea><br>

                        <strong> Description2 Ru :</strong>
                        <textarea type="text" value="<?php echo e(old('description2_ru')); ?>" name="description2_ru" class="form-control ckeditor"> 
                        </textarea><br>

                        <strong> Description2 En :</strong>
                        <textarea type="text" value="<?php echo e(old('description2_en')); ?>" name="description2_en" class="form-control ckeditor"> 
                        </textarea><br>

                        <strong> Brithday Uz :</strong>
                        <input type="text" name="brithday_uz" value="<?php echo e(old('brithday_uz')); ?>" class="form-control"> <br>

                        <strong> Brithday Ru :</strong>
                        <input type="text" name="brithday_ru" value="<?php echo e(old('brithday_ru')); ?>" class="form-control"> <br>

                        <strong> Brithday En :</strong>
                        <input type="text" name="brithday_en" value="<?php echo e(old('brithday_en')); ?>" class="form-control"> <br>


                        <strong> Website :</strong>
                        <input type="text" name="website" value="<?php echo e(old('website')); ?>" class="form-control"> <br>

                        <strong> Phone :</strong>
                        <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" class="form-control"> <br>

                        <strong> City Uz :</strong>
                        <input type="text" name="city_uz" value="<?php echo e(old('city_uz')); ?>" class="form-control"> <br>

                        <strong> City Ru :</strong>
                        <input type="text" name="city_ru" value="<?php echo e(old('city_ru')); ?>" class="form-control"> <br>

                        <strong> City En :</strong>
                        <input type="text" name="city_en" value="<?php echo e(old('city_en')); ?>" class="form-control"> <br>

                        <strong> Age :</strong>
                        <input type="text" name="age" value="<?php echo e(old('age')); ?>" class="form-control"> <br>

                        <strong> Dagree Uz :</strong>
                        <input type="text" name="dagree_uz" value="<?php echo e(old('dagree_uz')); ?>" class="form-control"> <br>

                        <strong> Dagree Ru :</strong>
                        <input type="text" name="dagree_ru" value="<?php echo e(old('dagree_ru')); ?>" class="form-control"> <br>

                        <strong> Dagree En :</strong>
                        <input type="text" name="dagree_en" value="<?php echo e(old('dagree_en')); ?>" class="form-control"> <br>

                        <strong> Email :</strong>
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control"> <br>

                        <strong> Freelance Uz :</strong>
                        <input type="text" name="freelance_uz" value="<?php echo e(old('freelance_uz')); ?>" class="form-control"> <br>

                        <strong> Freelance Ru :</strong>
                        <input type="text" name="freelance_ru" value="<?php echo e(old('freelance_ru')); ?>" class="form-control"> <br>

                        <strong> Freelance En :</strong>
                        <input type="text" name="freelance_en" value="<?php echo e(old('freelance_en')); ?>" class="form-control"> <br>

                        <strong> Rasm(png yoki jpg) :</strong>
                        <input type="file" name="img" value="<?php echo e(old('img')); ?>" class="form-control"> <br>

                        <input type="submit" value="Qo`shish">

                    </form>
                </div>

            </div>
        </main>
        <!-- MAIN -->

        <script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
        <script type="text/javascript">
            $(document).ready(function() {
               $('.ckeditor').ckeditor();
            });
        </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/abouts/create.blade.php ENDPATH**/ ?>