


<?php $__env->startSection('content'); ?>

<!-- MAIN -->
<main>


    <div class="table-data">
        <div class="order">
            <div class="head">
                <h3>Show</h3>
                <a class="create__btn" href="<?php echo e(route('admin.facts.index')); ?>"><i class="bi bi-backspace-fill"></i>Back</a>
            </div>
            <table>
                <tr>
                    <td>ID</td>
                    <td><?php echo e($fact->id); ?></td>
                </tr>
                <tr>
                    <td>Title</td>
                    <td><?php echo e($fact->title_uz); ?></td>
                </tr>
                <tr>
                    <td>Title</td>
                    <td><?php echo e($fact->title_ru); ?></td>
                </tr>
                <tr>
                    <td>Title</td>
                    <td><?php echo e($fact->title_en); ?></td>
                </tr>
                <tr>
                    <td>Happy Clients Number</td>
                    <td><?php echo e($fact->happy_clients_num); ?></td>
                </tr>
                <tr>
                    <td>Happy Clients Uz</td>
                    <td><?php echo e($fact->happy_clients_uz); ?></td>
                </tr>
                <tr>
                    <td>Happy Clients Ru</td>
                    <td><?php echo e($fact->happy_clients_ru); ?></td>
                </tr>
                <tr>
                    <td>Happy Clients En</td>
                    <td><?php echo e($fact->happy_clients_en); ?></td>
                </tr>
                <tr>
                    <td>Projects Number</td>
                    <td><?php echo e($fact->projects_num); ?></td>
                </tr>
                <tr>
                    <td>Projects Uz</td>
                    <td><?php echo e($fact->projects_uz); ?></td>
                </tr>
                <tr>
                    <td>Projects Ru</td>
                    <td><?php echo e($fact->projects_ru); ?></td>
                </tr>
                <tr>
                    <td>Projects En</td>
                    <td><?php echo e($fact->projects_en); ?></td>
                </tr>
                <tr>
                    <td>Hours of Support Number</td>
                    <td><?php echo e($fact->hours_of_support_num); ?></td>
                </tr>
                <tr>
                    <td>Hours of Support Uz</td>
                    <td><?php echo e($fact->hours_of_support_uz); ?></td>
                </tr>
                <tr>
                    <td>Hours of Support Ru</td>
                    <td><?php echo e($fact->hours_of_support_ru); ?></td>
                </tr>
                <tr>
                    <td>Hours of Support En</td>
                    <td><?php echo e($fact->hours_of_support_en); ?></td>
                </tr>
                <tr>
                    <td>Hard Workers Number</td>
                    <td><?php echo e($fact->hard_workers_num); ?></td>
                </tr>
                <tr>
                    <td>Hard Workers Uz</td>
                    <td><?php echo e($fact->hard_workers_uz); ?></td>
                </tr>
                <tr>
                    <td>Hard Workers Ru</td>
                    <td><?php echo e($fact->hard_workers_ru); ?></td>
                </tr>
                <tr>
                    <td>Hard Workers En</td>
                    <td><?php echo e($fact->hard_workers_en); ?></td>
                </tr>
            </table>
        </div>

    </div>
</main>
<!-- MAIN -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/facts/show.blade.php ENDPATH**/ ?>