


<?php $__env->startSection('content'); ?>

<!-- MAIN -->
<main>


    <div class="table-data">
        <div class="order">
            <div class="head">
                <h3>Show</h3>
                <a class="create__btn" href="<?php echo e(route('admin.forms.index')); ?>"><i class="bi bi-backspace-fill"></i>Back</a>
            </div>
            <table>
                <tr>
                    <td>ID</td>
                    <td><?php echo e($form->id); ?></td>
                </tr>
                <tr>
                    <td>Name</td>
                    <td><?php echo e($form->name); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?php echo e($form->email); ?></td>
                </tr>
                <tr>
                    <td>Number</td>
                    <td><?php echo e($form->number); ?></td>
                </tr>
                <tr>
                    <td>Subject</td>
                    <td><?php echo e($form->subject); ?></td>
                </tr>
                <tr>
                    <td>Message</td>
                    <td><?php echo e($form->message); ?></td>
                </tr>
            </table>
        </div>

    </div>
</main>
<!-- MAIN -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/forms/show.blade.php ENDPATH**/ ?>