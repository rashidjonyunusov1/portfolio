<div class="social-links mt-3 text-center">
    <?php $__currentLoopData = $social_network; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e($item->url); ?>" class="twitter"><i class="<?php echo e($item->icon); ?>"></i></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        <?php /**PATH C:\OSPanel\domains\portfolio\resources\views/sections/social_networks.blade.php ENDPATH**/ ?>