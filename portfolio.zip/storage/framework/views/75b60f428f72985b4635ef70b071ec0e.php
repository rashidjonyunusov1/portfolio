


<?php $__env->startSection('content'); ?>

<!-- MAIN -->
<main>


    <div class="table-data">
        <div class="order">
            <div class="head">
                <h3>Show</h3>
                <a class="create__btn" href="<?php echo e(route('admin.abouts.index')); ?>"><i class="bi bi-backspace-fill"></i>Back</a>
            </div>
            <table>
                <tr>
                    <td>ID</td>
                    <td><?php echo e($about->id); ?></td>
                </tr>
                <tr>
                    <td>Title Uz</td>
                    <td><?php echo e($about->title_uz); ?></td>
                </tr>
                <tr>
                    <td>Title Ru</td>
                    <td><?php echo e($about->title_ru); ?></td>
                </tr>
                <tr>
                    <td>Title</td>
                    <td><?php echo e($about->title_en); ?></td>
                </tr>
                <tr>
                    <td>Description1 Uz</td>
                    <td><?php echo $about->description1_uz; ?></td>
                </tr>
                <tr>
                    <td>Description1 Ru</td>
                    <td><?php echo $about->description1_ru; ?></td>
                </tr>
                <tr>
                    <td>Description1</td>
                    <td><?php echo $about->description1_en; ?></td>
                </tr>
                <tr>
                    <td>Description2 Uz</td>
                    <td><?php echo $about->description2_uz; ?></td>
                </tr>
                <tr>
                    <td>Description2 Ru</td>
                    <td><?php echo $about->description2_ru; ?></td>
                </tr>
                <tr>
                    <td>Description2</td>
                    <td><?php echo $about->description2_en; ?></td>
                </tr>
                <tr>
                    <td>Brithday</td>
                    <td><?php echo e($about->brithday_uz); ?></td>
                </tr>
                <tr>
                    <td>Brithday Uz</td>
                    <td><?php echo e($about->brithday_ru); ?></td>
                </tr>
                <tr>
                    <td>Brithday Ru</td>
                    <td><?php echo e($about->brithday_en); ?></td>
                </tr>
                <tr>
                    <td>Website</td>
                    <td><?php echo e($about->website); ?></td>
                </tr>
                <tr>
                    <td>Phone</td>
                    <td><?php echo e($about->phone); ?></td>
                </tr>
                <tr>
                    <td>City Uz</td>
                    <td><?php echo e($about->city_uz); ?></td>
                </tr>
                <tr>
                    <td>City Ru</td>
                    <td><?php echo e($about->city_ru); ?></td>
                </tr>
                <tr>
                    <td>City</td>
                    <td><?php echo e($about->city_en); ?></td>
                </tr>
                <tr>
                    <td>Age</td>
                    <td><?php echo e($about->age); ?></td>
                </tr>
                <tr>
                    <td>Dagree Uz</td>
                    <td><?php echo e($about->dagree_uz); ?></td>
                </tr>
                <tr>
                    <td>Dagree Ru</td>
                    <td><?php echo e($about->dagree_ru); ?></td>
                </tr>
                <tr>
                    <td>Dagree</td>
                    <td><?php echo e($about->dagree_en); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?php echo e($about->email); ?></td>
                </tr>
                <tr>
                    <td>Freelance Uz</td>
                    <td><?php echo e($about->freelance_uz); ?></td>
                </tr>
                <tr>
                    <td>Freelance Ru</td>
                    <td><?php echo e($about->freelance_ru); ?></td>
                </tr>
                <tr>
                    <td>Freelance</td>
                    <td><?php echo e($about->freelance_en); ?></td>
                </tr>
                <tr>
                    <td>Image</td>
                    <td>
                        <img src="/img/<?php echo e($about->img); ?>" width="80px">
                    </td>
                </tr>
            </table>
        </div>

    </div>
</main>
<!-- MAIN -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\portfolio\resources\views/admin/abouts/show.blade.php ENDPATH**/ ?>